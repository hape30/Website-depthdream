--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE vector_book;
--
-- Name: vector_book; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE vector_book WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Russian_Russia.1251';


ALTER DATABASE vector_book OWNER TO postgres;

\connect vector_book

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: active_conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.active_conversations (
    user_id bigint NOT NULL,
    active boolean NOT NULL
);


ALTER TABLE public.active_conversations OWNER TO postgres;

--
-- Name: active_conversations_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.active_conversations_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.active_conversations_user_id_seq OWNER TO postgres;

--
-- Name: active_conversations_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.active_conversations_user_id_seq OWNED BY public.active_conversations.user_id;


--
-- Name: encoded_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.encoded_messages (
    id integer NOT NULL,
    original_text text NOT NULL,
    encoded_vector bytea NOT NULL
);


ALTER TABLE public.encoded_messages OWNER TO postgres;

--
-- Name: encoded_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.encoded_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.encoded_messages_id_seq OWNER TO postgres;

--
-- Name: encoded_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.encoded_messages_id_seq OWNED BY public.encoded_messages.id;


--
-- Name: spatial_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.spatial_data (
    id integer NOT NULL,
    name character varying(100),
    geom public.geometry(Point,4326)
);


ALTER TABLE public.spatial_data OWNER TO postgres;

--
-- Name: spatial_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.spatial_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.spatial_data_id_seq OWNER TO postgres;

--
-- Name: spatial_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.spatial_data_id_seq OWNED BY public.spatial_data.id;


--
-- Name: active_conversations user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_conversations ALTER COLUMN user_id SET DEFAULT nextval('public.active_conversations_user_id_seq'::regclass);


--
-- Name: encoded_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.encoded_messages ALTER COLUMN id SET DEFAULT nextval('public.encoded_messages_id_seq'::regclass);


--
-- Name: spatial_data id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spatial_data ALTER COLUMN id SET DEFAULT nextval('public.spatial_data_id_seq'::regclass);


--
-- Data for Name: active_conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.active_conversations (user_id, active) FROM stdin;
\.
COPY public.active_conversations (user_id, active) FROM '$$PATH$$/5787.dat';

--
-- Data for Name: encoded_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.encoded_messages (id, original_text, encoded_vector) FROM stdin;
\.
COPY public.encoded_messages (id, original_text, encoded_vector) FROM '$$PATH$$/5785.dat';

--
-- Data for Name: spatial_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_data (id, name, geom) FROM stdin;
\.
COPY public.spatial_data (id, name, geom) FROM '$$PATH$$/5783.dat';

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.
COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM '$$PATH$$/5621.dat';

--
-- Name: active_conversations_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.active_conversations_user_id_seq', 1, false);


--
-- Name: encoded_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.encoded_messages_id_seq', 133, true);


--
-- Name: spatial_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.spatial_data_id_seq', 2, true);


--
-- Name: active_conversations active_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_conversations
    ADD CONSTRAINT active_conversations_pkey PRIMARY KEY (user_id);


--
-- Name: encoded_messages encoded_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.encoded_messages
    ADD CONSTRAINT encoded_messages_pkey PRIMARY KEY (id);


--
-- Name: spatial_data spatial_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spatial_data
    ADD CONSTRAINT spatial_data_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

